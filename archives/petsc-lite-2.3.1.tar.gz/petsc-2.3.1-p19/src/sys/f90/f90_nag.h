#if !defined(__F90_NAG_H)
#define __F90_NAG_H

#include "/soft/com/packages/nag-f95-5.0/bin/f95.h"
/* #include "/usr/local/lib/f90/f90.h" */

#define F90Array1d Dope1
#define F90Array2d Dope2
#define F90Array3d Dope3
#define F90Array4d Dope4

#endif
