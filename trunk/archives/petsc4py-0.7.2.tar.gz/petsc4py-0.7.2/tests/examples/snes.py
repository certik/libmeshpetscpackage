import petsc4py, sys
petsc4py.init(sys.argv)

from petsc4py.PETSc import *
